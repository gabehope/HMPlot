# Reusable charts and export

Keep chart definitions as ordinary functions or components and export through their handles.

## Return handles from reusable charts

A Python function can construct the same chart for several tables and return its Plot or individual mark handles. Each call creates independent components. Svelte components provide the same reuse: expose data props and bindable handles when callers need later updates.

## Choose an export format

PNG preserves the rendered image. SVG and PDF keep axes, text, legends and most 2D marks as vector shapes, and draw what has no vector form as images (the list below). Output size and fallback DPI serve different purposes: size controls the document, while DPI controls raster detail. Inspect the export report when vector purity matters.

## What is not exported as vector

In SVG and PDF exports, axes, tick labels, titles, [Title](/reference/svelte/title.md) blocks, legends (colorbars as gradients) and 2D marks are vector shapes and searchable text, except for what this section lists. With `mode="auto"` (the default) each item listed is drawn as an image at the export's raster DPI (300 by default), in its place among the vector shapes; `mode="vector"` refuses it and names it, and `mode="raster"` draws the whole plot as one image. The export report says what happened to each mark (`markOutcomes`, `rasterLayers` and `warnings`), and each component's reference page has a note, "SVG and PDF export", saying the same. An HTML export's SVG snapshot follows the same list.

Always an image:

- [Heatmap](/reference/svelte/heatmap.md), with any marks drawn into it; [Image](/reference/svelte/image.md); [Surface](/reference/svelte/surface.md); [Points3D](/reference/svelte/points-3d.md); [Text3D](/reference/svelte/text-3d.md), TeX included.
- [GeoJSON](/reference/svelte/geojson.md)'s filled polygons and [VectorTile](/reference/svelte/vector-tile.md)'s filled areas. A live VectorTile (the default in a 2D view) draws its roads, paths and boundaries as an image too, and keeps place names as text.
- A [Markdown](/reference/python/markdown.md) block, and a 2D [Minimap](/reference/svelte/minimap.md), in a [Scene](/reference/python/scene.md)'s export.

The whole plot as one image (all its marks, with the effect, in one image; its axes, titles and legends stay vector):

- A [Plot](/reference/svelte/plot.md)'s sky, fog or plugin [effects](/reference/svelte/effects.md) (a bloom effect alone changes nothing), a mark's `glow`, or a [Frame](/reference/svelte/frame.md)'s `atmosphere`.

An image only in some cases, each for a reason a vector cannot carry:

- A 3D view (a 3D [Plot](/reference/svelte/plot.md) or [Frame](/reference/svelte/frame.md)) holding a mark with no vector form there: a 3D mark ([Points3D](/reference/svelte/points-3d.md), [Arrows3D](/reference/svelte/arrows-3d.md), [Text3D](/reference/svelte/text-3d.md), [Surface](/reference/svelte/surface.md), a [Prism](/reference/svelte/prism.md), an extruded [Rect](/reference/svelte/rect.md)), a [Heatmap](/reference/svelte/heatmap.md) or [Image](/reference/svelte/image.md), a lit or additive mark, or a globe or polar frame ([GeoJSON](/reference/svelte/geojson.md) boundaries on a globe too). All of that view's marks are then one image, since an image and vector shapes cannot hide one another correctly; the axes stay vector. Other 3D views are vector: their 2D marks are projected through the camera and drawn back to front by depth, which is approximate where marks intersect or cross closely (the report says so).
- A [Prism](/reference/svelte/prism.md) extruded along x or y: a 2D view sees its side, not its footprint.
- `blend="additive"` or `"subtractive"`: PDF has no additive blend mode, and SVG's is not honored by Illustrator, Inkscape or SVG-to-PDF converters. Screen and multiply stay vector (as `mix-blend-mode`).
- A mark with more vector pieces than the export's primitive budget (100,000 by default), a guard against huge files; raise `primitiveBudget` to keep it vector.
- A band, [Rect](/reference/svelte/rect.md) or sector cut by a Mercator map's latitude limit, or crossed by a map's seam more than once. One crossed once exports a piece on each side of the seam.

Colors from a scale are vector: a `fill` or `color` column of numbers is evaluated through its scale and colormap as the GPU evaluates it, and a column of categories gives each row its category's color, on every 2D mark ([Points](/reference/svelte/points.md), [Line](/reference/svelte/line.md), [Segments](/reference/svelte/segments.md), [Arrows](/reference/svelte/arrows.md), [Arrows3D](/reference/svelte/arrows-3d.md), [Area](/reference/svelte/area.md), [ErrorBars](/reference/svelte/error-bars.md), [Text](/reference/svelte/text.md), [Rect](/reference/svelte/rect.md), [Bar](/reference/svelte/bar.md), [Prism](/reference/svelte/prism.md), [Polygon](/reference/svelte/polygon.md), [Pie](/reference/svelte/pie.md), [GeoJSON](/reference/svelte/geojson.md) and the marks built from them, such as [BoxPlot](/reference/svelte/box-plot.md), [Violin](/reference/svelte/violin.md), [Ecdf](/reference/svelte/ecdf-chart.md), [DensityContour](/reference/svelte/density-contour.md), [DensityBands](/reference/svelte/density-bands.md), [Swarm](/reference/svelte/swarm.md), [RuleX](/reference/svelte/rule-x.md) and [RuleY](/reference/svelte/rule-y.md)). `dash` is a dash pattern ([Line](/reference/svelte/line.md), [Segments](/reference/svelte/segments.md), [RuleX](/reference/svelte/rule-x.md), [RuleY](/reference/svelte/rule-y.md), [Routes](/reference/svelte/routes.md)); every `curve` is a curve, on maps too; [Dodge](/reference/svelte/dodge.md) and [Swarm](/reference/svelte/swarm.md)'s displaced points keep their connectors.

Left out of every static export (PNG, SVG and PDF): the inputs ([Slider](/reference/svelte/slider.md), [Checkbox](/reference/svelte/checkbox.md), [Select](/reference/svelte/select.md), [Button](/reference/svelte/button.md), [Playback](/reference/svelte/playback.md)), a [Crosshair](/reference/svelte/crosshair.md), a Plot's `overview` gadget, and a [Minimap](/reference/svelte/minimap.md) of a 3D plot (the report's warnings say so).

## Notebook and headless export

In a notebook, await plot.export_png("plot.png") or export_svg/export_pdf to capture an interacted view. A notebook open in a browser without WebGPU shows a static image of the scene instead, drawn by the kernel in its headless Chrome; set the environment variable HMPLOT_NOTEBOOK_SVG=1 to save that SVG in the notebook's outputs too, for viewers such as GitHub and nbviewer. With the optional export dependency installed, filename on a Plot, Facet, or Scene saves after a successful construction context exits. Context autosave uses a fresh camera, not a notebook’s current navigation.

## Interactive HTML

Python/declarative scenes can export self-contained HTML with accepted data and configuration. The opened file still needs WebGPU. Python callbacks do not become browser Python programs; they are omitted. Arbitrary direct-Svelte children cannot be reconstructed by this export path.

## Try one change

Call trend with a different table. Use background="transparent" for compositing. In a notebook, save with await plot.export_svg("trend.svg") after checking the on-screen result.

```python
import hmplot as hm

data = {"x":[1,2,3,4,5,6],"y":[2,4,3,6,5,7],"group":["A","A","A","B","B","B"],"score":[10,25,40,60,75,95]}

def trend(data):
    with hm.Plot(data=data, height=340, axes2d=True, background="white") as plot:
        hm.Line(x="x", y="y", color="#547ba2")
        hm.Points(x="x", y="y", fill="#547ba2")
    return plot

plot = trend(data)
plot
```

```svelte
<script>
  import { Plot, Line, Points } from "hmplot";
  const data = {"x":[1,2,3,4,5,6],"y":[2,4,3,6,5,7],"group":["A","A","A","B","B","B"],"score":[10,25,40,60,75,95]};
</script>

<Plot {data} height={340} axes2d background="white">
  <Line x="x" y="y" color="#547ba2" />
  <Points x="x" y="y" fill="#547ba2" />
</Plot>
```
