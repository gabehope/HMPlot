# Layering marks

Compose a chart from separate marks so each layer has one responsibility.

## A band, an estimate, and observations

Area draws the interval between lower and upper values at each x. Line draws the central estimate; Points makes its samples visible. These marks use the same table and coordinate frame. A ribbon does not calculate confidence intervals: its bounds must come from data or a transform.

## Ordering and grouping

Lines connect observations in supplied order. They do not sort by X. Use series to partition multiple trajectories independently from color: subjects may share a treatment color without being connected to each other. Missing coordinates break a path.

## Share channels without hiding structure

Mapping can supply common x, y, fill, or appearance defaults to descendant marks. Explicit mark properties override that scope. Mapping does not aggregate rows; Group is the aggregation transform.

## Try one change

Remove Points to leave only the estimate and uncertainty band. Set Area opacity to 0.1 for a lighter interval.

```python
import hmplot as hm

data = {"x":[1,2,3,4,5,6],"y":[2,4,3,6,5,7],"group":["A","A","A","B","B","B"],"score":[10,25,40,60,75,95],"lower":[1.2,3.2,2.2,5.2,4.2,6.2],"upper":[2.8,4.8,3.8,6.8,5.8,7.8]}

with hm.Plot(data=data, height=340, axes2d=True) as plot:
    hm.Area(x="x", lower="lower", upper="upper", fill="#547ba2", opacity=0.2)
    hm.Line(x="x", y="y", color="#315878", width=2)
    hm.Points(x="x", y="y", fill="#315878", size=4)

plot
```

```svelte
<script>
  import { Plot, Area, Line, Points } from "hmplot";
  const data = {"x":[1,2,3,4,5,6],"y":[2,4,3,6,5,7],"group":["A","A","A","B","B","B"],"score":[10,25,40,60,75,95],"lower":[1.2,3.2,2.2,5.2,4.2,6.2],"upper":[2.8,4.8,3.8,6.8,5.8,7.8]};
</script>

<Plot {data} height={340} axes2d>
  <Area x="x" lower="lower" upper="upper" fill="#547ba2" opacity={0.2} />
  <Line x="x" y="y" color="#315878" width={2} />
  <Points x="x" y="y" fill="#315878" size={4} />
</Plot>
```
