# Coordinates and surfaces

The same data can be drawn in Cartesian, polar or spherical coordinates, and frames nest to combine them.

## Cartesian, polar and spherical

Cartesian coordinates map X/Y/Z through their frame scales. Polar coordinates interpret X as angle, Y as radius, and Z as axial height. Spherical coordinates interpret them as longitude, latitude, and radial offset. A Plot has one root coordinate system: set coordinates on the Plot, or wrap all of its marks in one Frame, which becomes the root. Each axis is titled by the column its marks plot there (`x="hour"` titles x "hour"), unless you give it a label.

## Read the polar example

The example measures angle in hours: angleUnit="custom" with anglePeriod={24} makes one turn 24 units, so 6 is a quarter turn. Angles default to degrees; radians and "extent" (the X domain is one turn) are the other units. Angle zero points right and positive angles turn counterclockwise. The point size stays in screen pixels while radial distance is in coordinate units. Negative effective radii are excluded, and a line that crosses one is cut rather than drawn through the center.

## Globes and maps

Spherical coordinates with projection="orthographic" draw a globe. Drag it to rotate; projectionCenter sets the longitude and latitude that face the viewer, and the viewport reports it as center. Points on the far side are hidden, and lines, bands, rectangles, heatmaps and GeoJSON are cut at the horizon instead of drawn through the globe. A 2D globe draws the sphere's outline and a graticule, a line every 15° without labels (an axis's step or tickCount draws labeled lines of its own), unless axes2d is false. The globe fills the plot area; `z={domain: [-1, 1]}` draws it at half size, with room around it. HMPlot bundles no land or coastline layer: draw one from your own GeoJSON (or a VectorTile source) as a mark on the globe. Flat equirectangular and Mercator maps repeat across the antimeridian as you pan, and a map nested in another frame cuts its paths there.

## Nested frames

A Frame inside a Plot owns its own scales and may set its own coordinates. Give it x and y ranges in the parent's data coordinates and it is drawn through the parent: a Cartesian chart in a polar parent becomes an annular sector, one on a globe wraps over the surface, and a polar or globe child fits into its box. A child that sets a range but no domain fits its own data. Give it a placement instead to pin a fixed-size frame to a parent data position; on a globe it lies flat on the surface. Marks, guides, picks and vector export follow the whole chain, and the few combinations that are not supported yet, such as a Surface in a nested Frame, report an error instead of drawing incorrectly. See the Nested scales, Anchored frame, Polar and tangent insets, and Solar system frames examples.

## Surfaces and textures

A scalar Heatmap can use surfaceMode and zScale for relief. Its fill still determines color. Children of a Heatmap paint an interactive surface texture. Globe geometry, surface relief, and texture raster resolution have different costs; increasing one does not necessarily improve the others.

## Try one change

Set anglePeriod to 12 to wrap the day twice around the dial. For a globe, use coordinates="spherical" with projection="orthographic" and geographic longitude and latitude. See the Earth and extruded GeoJSON examples for textures and lighting. A 3D globe or map can also take a sky behind it (a star map or a gradient) and distance fog, both Plot [effects](/reference/svelte/effects.md), an `atmosphere` around a spherical Frame's globe, and `glow` on its marks with a bloom effect; the solar system example uses each.

```python
import hmplot as hm

data = {"hour":[0,3,6,9,12,15,18,21,24],"activity":[1,0.6,1.4,2.4,2.8,2.5,2.2,1.6,1]}

with hm.Plot(data=data, coordinates="polar", angle_unit="custom", angle_period=24,
             x={"domain":[0,24]}, y={"domain":[0,3]}, height=340, axes2d=True) as plot:
    hm.Line(x="hour", y="activity", color="#547ba2")
    hm.Points(x="hour", y="activity", size=5)

plot
```

```svelte
<script>
  import { Plot, Line, Points } from "hmplot";
  const data = {"hour":[0,3,6,9,12,15,18,21,24],"activity":[1,0.6,1.4,2.4,2.8,2.5,2.2,1.6,1]};
</script>

<Plot {data} coordinates="polar" angleUnit="custom" anglePeriod={24}
  x={{domain:[0,24]}} y={{domain:[0,3]}} height={340} axes2d>
  <Line x="hour" y="activity" color="#547ba2" />
  <Points x="hour" y="activity" size={5} />
</Plot>
```
