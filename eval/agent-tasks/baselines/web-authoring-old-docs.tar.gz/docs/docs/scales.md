# Scales

Separate normalization of source values from their encoding as colors, sizes, or widths.

## Position and appearance

A Plot's or Frame's axes (`x`, `y` and `z`) determine where values fall in space. Set an x or y domain explicitly when comparisons need a fixed coordinate range. Appearance scales determine colors, sizes, or widths. In this example, score drives both color and size, but those channels have different output ranges.

## Share meaning explicitly

A normalization maps the domain [0, 100] into a normalized interval. The color scale maps that interval into a custom three-color colormap; the size scale maps it into [8, 22] pixels. Sharing the normalization keeps their data meaning consistent. Sharing a complete scale resource across plots also shares its output mapping.

## Automatic sharing has boundaries

Named numeric columns can share compatible automatic appearance mappings within a frame. A same-named column in an unrelated Data scope is not the same data identity. Use explicit resources when separate datasets must be compared. In facets, resolve controls shared versus independent appearance domains.

## Categorical versus ordinal

categorical assigns palette colors or symbols to categories. ordinal uses an explicit ordered domain sampled along a colormap. Numerical values remain continuous unless you explicitly request a categorical mapping. Explicit scale ranges are independent of a theme’s inferred palette.

## Custom colormaps and RGB

A colormap can be a built-in name, a list of colors such as `["#2166ac", "#f7f7f7", "#b2182b"]`, or `{colors, space, positions}`. A theme can set the default colormap for continuous fills that have none. When the data already holds colors, pass `fill={{r: "red", g: "green", b: "blue"}}` or an N x 3 array instead: integers are 0-255, floats 0-1, and no scale or legend applies.

## Try one change

Change the normalization domain to [0, 200]. Both size and color now show that every observation occupies the lower half of the same measurement range. Then replace the list of colors with `"Magma"`, or with `{colors: [...], positions: [0, 0.8, 1]}` to save the darkest color for the top of the range.

```python
import hmplot as hm

data = {"x":[1,2,3,4,5,6],"y":[2,4,3,6,5,7],"group":["A","A","A","B","B","B"],"score":[10,25,40,60,75,95]}

norm = hm.normalization(domain=[0, 100])
colors = hm.continuous(normalization=norm, colormap=hm.colormap(["#fdd49e", "#ef6548", "#7f0000"]))
sizes = hm.continuous(normalization=norm, range=[8, 22])

with hm.Plot(data=data, height=340, axes2d=True) as plot:
    hm.Points(x="x", y="y", fill="score", size="score",
                     fill_scale=colors, size_scale=sizes)

plot
```

```svelte
<script>
  import { Plot, Points, continuous, normalization } from "hmplot";
  const data = {"x":[1,2,3,4,5,6],"y":[2,4,3,6,5,7],"group":["A","A","A","B","B","B"],"score":[10,25,40,60,75,95]};
  const norm = normalization({ domain: [0, 100] });
  // A custom colormap: a list of colors, interpolated in Lab (a name such as "Viridis" works too).
  const colors = continuous({ normalization: norm, colormap: ["#fdd49e", "#ef6548", "#7f0000"] });
  const sizes = continuous({ normalization: norm, range: [8, 22] });
</script>

<Plot {data} height={340} axes2d>
  <Points x="x" y="y" fill="score" size="score"
    fillScale={colors} sizeScale={sizes} />
</Plot>
```
