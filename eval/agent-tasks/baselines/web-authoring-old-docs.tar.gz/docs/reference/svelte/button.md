# Button

Counts the viewer's presses, so a prop that acts on each change of its value (reset=, refresh=) acts on each press.

## Example

```svelte
<script>
  import { Button, InputContext, Plot, Points, Sample, input } from "hmplot";
  const data = { x: [1, 2, 3, 4, 5, 6, 7, 8], y: [3, 1, 4, 1, 5, 9, 2, 6] };
</script>

<!-- Each press adds one to the button's value, so the Sample draws with a new seed. -->
<InputContext>
  <Button name="draw" />
  <Plot {data} height={300} axes2d>
    <Sample size={4} seed={input("draw")}>
      <Points x="x" y="y" />
    </Sample>
  </Plot>
</InputContext>
```

## Options

- `value` (`number`): The count before the first press. Default: `0`.
- `name` (`string`): The name readers use (input("name"), hm.input.name, or "$name" where a string names a column): an identifier, unique in its input context.
- `label` (`string`): The text shown beside the control. Default: the name.

## Usage

An input sends its value up to the nearest input context (an InputContext, a Python Scene, or a Template instance), and everything in that context reads it by name: `input("name")` in JavaScript, `hm.input.name` in Python, or the string `"$name"` where a string names a column. A read is replaced by the value before its reader sees it, so moving an input re-runs its readers once, and the change animates like any other data change. Inputs go beside Plots (in a Row or Column), not inside them.

> **SVG and PDF export**
>
> **Left out.** PNG, SVG and PDF exports leave inputs out, and show the plots at the inputs' current values. See [what is not exported as vector](/docs/export.md).

## Related examples

- [Inputs](/examples/inputs.md)
