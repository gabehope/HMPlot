# Treemap

A hierarchy drawn as nested rectangles, each leaf's area set by its value.

## Example

```svelte
<script>
  import { Plot, Treemap, Nodes, Rect, GraphData } from "hmplot";
  const data = {
    source: ["root", "root", "a", "a", "a", "b", "b"],
    target: ["a", "b", "a1", "a2", "a3", "b1", "b2"],
  };
</script>

<Plot {data} height={300}>
  <GraphData source="source" target="target"
    ><Treemap root="root" padding={0.02}>
      <Nodes><Rect x0="x0" x1="x1" y0="y0" y1="y1" fill="depth" /></Nodes>
    </Treemap></GraphData
  >
</Plot>
```

## Options

- `paddingInner` (`number`): The gap between sibling rectangles. Default: padding. In data units.
- `paddingOuter` (`number`): The gap between a parent's edges and its children. Default: padding. In data units.
- `tile` (`"squarify" | "resquarify" | "binary" | "slice" | "dice" | "sliceDice"`): How each rectangle is split among its children, by d3's tiling methods. Default: `"squarify"`.
- `root` (`string | number | boolean`): The ID of the hierarchy's root node.
- `value` (`column | expression`): Each leaf's nonnegative weight, which sets its rectangle's area: a nodes-table column or an expression over it. A parent holds the sum of its leaves. Default: `1`.
- `width` (`number`): The width of the rectangle the layout divides. Default: `1` data units.
- `height` (`number`): The height of the rectangle the layout divides. Default: `1` data units.
- `padding` (`number`): The gap around and between rectangles, where paddingInner and paddingOuter do not set their own. Default: `0` data units.

## Usage

`Treemap` uses d3-hierarchy to subdivide one connected, directed hierarchy. Supply the edges (and nodes, or let it infer them) and endpoint mapping through GraphData; set `root` on Treemap. `value` evaluates on node columns; leaf values determine area and default to 1. `width` and `height` default to 1. `padding`, `paddingInner`, and `paddingOuter` control gaps. `tile` selects `squarify` (default), `resquarify`, `binary`, `slice`, `dice`, or `sliceDice`.

Inside `<Nodes>`, `x0`, `x1`, `y0`, and `y1` give rectangles; `x`, `y`, and `position` give centers. `parent`, `depth`, `degree`, and node attributes are also available. `<Edges>` retains source rows and exposes center-to-center `start` and `end`.

## Related examples

- [Treemap](/examples/treemap-hierarchy.md)
