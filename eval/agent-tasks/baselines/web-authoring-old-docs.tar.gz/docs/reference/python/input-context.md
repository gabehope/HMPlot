# InputContext

A scope for inputs: everything inside it reads the inputs inside it by name (a Python Scene is one already).

## Example

```python
import hmplot as hm

data = {"x": [1, 2, 3, 4], "y": [3, 1, 4, 2]}
with hm.InputContext() as inputs:
    hm.Slider(name="size", min=1, max=10, value=4)
    with hm.Plot(data=data, height=300, axes2d=True):
        hm.Points(x="x", y="y", size=hm.input.size)
inputs
```

## Usage

An input sends its value up to the nearest input context (an InputContext, a Python Scene, or a Template instance), and everything in that context reads it by name: `input("name")` in JavaScript, `hm.input.name` in Python, or the string `"$name"` where a string names a column. A read is replaced by the value before its reader sees it, so moving an input re-runs its readers once, and the change animates like any other data change. Inputs go beside Plots (in a Row or Column), not inside them, and are left out of image and PDF exports.

## Related examples

- [Inputs](/examples/inputs.md)
