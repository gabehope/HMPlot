# Segments

Line segments, one per row, each from its start to its end.

## Example

```python
import hmplot as hm

start = [[0, 0], [1, 2], [2, 1]]
end = [[1, 1], [2, 3], [4, 0]]
with hm.Plot(height=300, axes2d=True) as plot:
    hm.Segments(start=start, end=end)
plot
```

## Options

Keywords are snake_case.

### Options

- `connections` (`connect()`): Draw between other marks instead of from start and end: connect(a, b, {key}) draws a segment for each matched key and pair of adjacent endpoints.
- `dash` (`boolean | number | [number, number]`): Draw the line dashed: true (4 px dashes and gaps), a dash length (gaps as long), or [dash, gap], measured along the drawn path. In px.
- `curve` (`"linear" | "step" | "step-before" | "step-after" | "link-horizontal" | "link-vertical" | "quadratic" | "cubic"`): How each segment runs from start to end: straight, in steps, as a tree link, or as a Bézier curve through its control points. Default: "linear", or "cubic" when control points are given.
- `control1` (`channel`): Each segment's first control point for a quadratic or cubic curve: a column of positions or an N x 2 (N x 3) array. Without curve, control points make the segments cubic.
- `control2` (`channel`): Each segment's second control point for a cubic curve; left out of an automatic cubic, it is the segment's end.
- `cap` (`"none" | "bar" | "arrow"`): "bar": a bar across both ends; "arrow": an arrowhead at the true end, following the curve. Default: `"none"`.
- `cap_size` (`number`): The length of the bars cap="bar" draws. Default: `6` px.
- `head_length` (`number`): The length of cap="arrow" heads, limited to the segment's length. Default: `10` px.
- `head_width` (`number`): The width of cap="arrow" heads. Default: `8` px.
- `data` (`table`): A table for this mark alone: a mark with data displays on its own, in a Plot of its own.

### Appearance

- `color` (`channel`): The line or text color: a CSS color, or a column mapped to colors. Default: the theme's (#3478c7 in the default theme).
- `width` (`channel`): The line width: a number, or a column mapped to widths. Default: the theme's (1 in the default theme). In px.
- `opacity` (`channel`): The opacity, 0 to 1: a number, or a column (categories map through opacity_scale). Default: `1`.

### Scales

- `color_scale` (`scale`): A scale for color that marks can share.
- `colormap` (`string | color[] | object`): The colormap of a numeric fill or color: a name, a list of colors, or {colors, space, positions}. Default: the theme's (Viridis).
- `width_scale` (`scale`): A scale for width that marks can share, as size_scale.
- `opacity_scale` (`scale`): A categorical() scale from the opacity column's categories to opacities, 0 to 1.

### Display

- `label` (`string`): The mark's name in the legend and the settings pane.
- `legend` (`boolean`): Whether the mark has a legend entry. Default: `True`.
- `visible` (`boolean`): Whether the mark is drawn. Default: `True`.
- `domains` (`boolean`): Whether the mark's data counts toward its axes' automatic domains; false leaves them to the other marks (a reference line, a decorative part). Default: `True`.
- `rows` (`"auto"`): "auto" draws one item when no channel reads a column (a line at a value, a label at a point), instead of one per row of the data; "@" view-state fields are not columns.
- `blend` (`"normal" | "additive" | "multiply" | "screen" | "subtractive"`): How the mark mixes with what is drawn under it; any mode but normal draws it transparent, and SVG and PDF exports draw additive and subtractive as an image. Default: `"normal"`.
- `glow` (`number`): How much the mark glows: its own color times glow blooms around it in the plot's presentation (0 does not glow); the Plot's bloom effect sets the bloom's strength and radius. SVG and PDF exports draw the whole plot as an image. Default: `0`.
- `shade` (`ShadeSpec`): A plugin's shade (registerPlugin): { kind, ...parameters }, as { kind: "hatch", spacing: 6 } (Python hm.shade("hatch", spacing=6)), recolors each fragment the mark draws; picking, tooltips, domains and legends are unchanged. SVG and PDF exports draw a shaded mark as an image.
- `options` (`string[]`): The settings the settings pane shows for this mark, by name.
- `name` (`string`): The mark's name in the settings pane, and the name facet.endpoint() and partition.endpoint() find it by.

### Interaction

- `identity` (`identity`): Whose rows these are for selections: an identity() shared by tables that show the same things. Default: its data's.
- `select` (`boolean | selection`): Click to replace the selection; an exact repeat clears it. Shift/Meta/Ctrl-click toggles membership (whole series for Line, Area): true uses its data's selection, or give a selection().
- `hover` (`boolean | selection`): Mark the row under the pointer as @hovered (a whole series for Line, Area), without fading the others: true uses its data's hover, or give a selection().
- `tooltip` (`boolean | field[] | object`): Show the nearest row's values in a box by the pointer: true, a list of fields, or {fields, radius, content}. Default: the Plot's.
- `nearest` (`boolean | selection | object`): Mark the row a tooltip shows as @nearest, with or without the tooltip: under the pointer, else the nearest drawn row within radius pixels (a whole series for Line, Area): true, a selection(), or {selection, radius}. Default: the Plot's.
- `respond` (`boolean | "selected" | "brushed" | "hovered" | "nearby" | "nearest" | selection | array`): Which interaction states fade this mark's other rows to selection_opacity; "hovered" fades them while hovering, "nearest" while a row is nearest. Default: the states it sets, except hover and nearest.
- `selection_opacity` (`number`): The opacity of the rows outside the selection while one is active. Default: `0.25`.
- `enter_effect` (`boolean | "fade" | object`): How rows that arrive in a keyed update appear: "fade", or {effect, duration, easing}. animate()'s enter option is the value a channel starts from.
- `exit_effect` (`boolean | "fade" | object`): How rows that leave in a keyed update disappear, as enter_effect. animate()'s exit option is the value a channel ends at.

### Animation

- `animation` (`boolean`): Animate changes to the mark's values. Default: `False`.
- `animation_duration` (`number`): How long an animated change takes. Default: `300` ms.
- `animation_easing` (`"linear" | "quad-in" | "quad-out" | "quad-in-out" | "cubic-in" | "cubic-out" | "cubic-in-out" | "sine-in-out"`): The animation's easing. Default: `"cubic-in-out"`.

### Segment ends

- `start` (`channel`): Where each segment starts (Segments, Arrows): a column of positions or an N x 2 (N x 3) array.
- `end` (`channel`): Where each segment ends, as start.

### Map paths

- `interpolation` (`"great-circle" | "angular" | "cartesian"`): How a path between two points runs on a map or a globe: along a great circle, straight in longitude and latitude, or straight in space. Default: `"great-circle"`.

### Legend settings

- `legend_font_size` (`number`, setting): The size of the mark's legend text. Default: the theme's (14 in the default theme). In px.
- `legend_font_family` (`string`, setting): The font of the mark's legend text, a CSS font-family. Default: the plot's font.
- `legend_text_color` (`color`, setting): The color of the mark's legend text. Default: `"#40505d"`.
- `legend_tick_format` (`string`, setting): How a colorbar labels numbers: a d3-format string, or a %-pattern for dates. Default: `".3~g"`.

### Color settings

- `quantize` (`boolean`, setting): Step a numeric fill or color into `levels` colors instead of a smooth gradient. Default: `False`.
- `levels` (`number`, setting): How many colors quantize steps through. Default: `10`.

### Limits

- `max_elements` (`number`, setting): The most rows the mark prepares on the GPU. Default: `250000`.

### The mark's own axes

- `x_transform` (`"linear" | "log" | "sqrt" | "symlog"`, setting): This mark's own x transform, instead of its frame's. Default: its frame's.
- `x_invert` (`boolean`, setting): Reverse this mark's x direction. Default: `False`.
- `xbounds` (`[number, number]`, setting): The x extent this mark maps, instead of its frame's domain (an image's or a grid's extent). Default: its frame's.
- `xrange` (`[number, number]`, setting): Where this mark's x extent lands, in its frame's world units. Default: its frame's.
- `y_transform` (`"linear" | "log" | "sqrt" | "symlog"`, setting): This mark's own y transform, instead of its frame's. Default: its frame's.
- `y_invert` (`boolean`, setting): Reverse this mark's y direction. Default: `False`.
- `ybounds` (`[number, number]`, setting): The y extent this mark maps, instead of its frame's domain (an image's or a grid's extent). Default: its frame's.
- `yrange` (`[number, number]`, setting): Where this mark's y extent lands, in its frame's world units. Default: its frame's.
- `z_transform` (`"linear" | "log" | "sqrt" | "symlog"`, setting): This mark's own z transform, instead of its frame's. Default: its frame's.
- `z_invert` (`boolean`, setting): Reverse this mark's z direction. Default: `False`.
- `zbounds` (`[number, number]`, setting): The z extent this mark maps, instead of its frame's domain (an image's or a grid's extent). Default: its frame's.
- `zrange` (`[number, number]`, setting): Where this mark's z extent lands, in its frame's world units. Default: its frame's.

### Shading

- `transparent` (`boolean`, setting): Draw the mark in the transparent pass, blended in depth order with other transparent marks. Default: `False`.

### Advanced renderer options

- `max_instances` (`number | null`): The most rows drawn; past it the rows are sampled (null draws them all), though SVG and PDF exports draw every row. Default: `None`.

## Usage

Each start/end pair is one observation. Independent segments do not infer neighboring rows. Curve controls may be supplied per segment; source identities survive subdivision. `cap="bar"` draws a bar `capSize` pixels long (6 by default) across each segment at both ends, as ErrorBars' caps; a curved segment's bars stand across its direction at its ends, and a segment cut at a horizon or seam has no bar at the cut.

`cap="arrow"` draws an arrowhead at the true end. `headLength` (10) and `headWidth` (8) are CSS pixels; the head follows a curve's final segment. These settings also appear in the settings pane. Zooming keeps the head's pixel size.

> **SVG and PDF export**
>
> **Vector, except** in a 3D view that holds a mark with no vector form there (Points3D, Surface or another 3D mark, a Heatmap or Image, a lit or additive mark, a globe or polar frame): then SVG and PDF exports draw all of that view's marks as one image, and `mode="vector"` refuses it. In other 3D views the segments are vectors too, drawn back to front by depth (approximate where marks cross closely). A `color` column, `dash` and every `curve`, on maps too, stay vector. See [what is not exported as vector](/docs/export.md).

### Connections

With `connections={connect(a, b)}` Segments draw one segment per matched key between the positions of two other marks; `connect(a, b, c)` draws a to b and b to c. See [connect()](connect).

## Related examples

- [Lines & vector fields](/examples/paths.md)
